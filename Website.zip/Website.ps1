Configuration Website
{
  param 
  (
    [string]$Action = "Present",
   	[array]$xBoxTasks = @("XblGameSaveTaskLogon","XblGameSaveTask")
 
  )

  Import-DscResource -ModuleName PSDesiredStateConfiguration
  Import-DscResource -ModuleName xComputerManagement

  Node 'localhost'
  {
    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure = $Action
      Name = "Web-Server"
    }

    #Install ASP.NET 4.5
    WindowsFeature ASP
    {
      Ensure = $Action
      Name = "Web-Asp-Net45"
    }

     WindowsFeature WebServerManagementConsole
    {
        Name = "Web-Mgmt-Console"
        Ensure = $Action
    }

    # Disable xBox sheduled tasks
    foreach ($task in $xBoxTasks) 
    {
        xScheduledTask  $Task
        {

	    TaskName = "$task"
        TaskPath = '\Microsoft\XblGameSave\'
        Enable = $false
        ActionExecutable = '%windir%\System32\XblGameSaveTask.exe'
        ScheduleType = "Once"
        RepeatInterval = 0

        }
    }

  }
} 