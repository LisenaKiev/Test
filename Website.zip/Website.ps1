Configuration Website
{
  param (
      $MachineName="localhost",
	    $Action
  )

  Import-DscResource -ModuleName xComputerManagement

  Node $MachineName
  {
    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure = $Action
      Name = "Web-Server"
    }

    #Install ASP.NET 4.5
    WindowsFeature ASP
    {
      Ensure = $Action
      Name = "Web-Asp-Net45"
    }

     WindowsFeature WebServerManagementConsole
    {
        Name = "Web-Mgmt-Console"
        Ensure = $Action
    }

    xScheduledTask  DisableXboxTasks
    {
          TaskName = 'XblGameSaveTask'
          TaskPath = '\Microsoft\XblGameSave'
          Enable = $false
          ActionExecutable = '%windir%\System32\XblGameSaveTask.exe'
          Ensure = $false
    }

  }
} 